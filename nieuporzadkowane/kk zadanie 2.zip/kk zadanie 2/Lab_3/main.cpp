#include <iostream>
#include <stdio.h>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <stdlib.h>
#include <cmath>
using namespace std;
/**
* bardzo prosta wersja szyfrowania, zak�ada wy��cznie macierze 5x5
*/
std::map <string,float> mapa_monogram;
std::map <string,float> mapa_digram;
std::map <string,int> mapa;
std::map <string,int> mapa2;


struct obiekt
{
    std::string wstepne_litery;
    std::string klucz;
    std::map <string,int> mapa_obiektu_monogram;
    std::map <string,int> mapa_obiektu_digram;
    float evaluation;
};

struct obiekt tablica[1000];

void uzupelnianie_map(std::map<string,float> &mapa_monogram, std::map<string,float> &mapa_digram)
{
    mapa_monogram.insert( std::pair<string,float>("e",12.49) );
    mapa_monogram.insert( std::pair<string,float>("t",9.28) );
    mapa_monogram.insert( std::pair<string,float>("a",8.04) );
    mapa_monogram.insert( std::pair<string,float>("o",7.64) );
    mapa_monogram.insert( std::pair<string,float>("i",7.57) );
    mapa_monogram.insert( std::pair<string,float>("n",7.23) );
    mapa_monogram.insert( std::pair<string,float>("s",6.51) );
    mapa_monogram.insert( std::pair<string,float>("r",6.28) );

    mapa_digram.insert( std::pair<string,float>("th",3.56) );
    mapa_digram.insert( std::pair<string,float>("he",3.07) );
    mapa_digram.insert( std::pair<string,float>("in",2.43) );
    mapa_digram.insert( std::pair<string,float>("er",2.05) );
    mapa_digram.insert( std::pair<string,float>("an",1.99) );
    mapa_digram.insert( std::pair<string,float>("re",1.85) );
    mapa_digram.insert( std::pair<string,float>("on",1.76) );
}
void czysc_tekst(string &tekst)
{
    int dlugosc;
    std::transform(tekst.begin(), tekst.end(), tekst.begin(), ::tolower);
    for(auto iter = tekst.begin();iter<tekst.end();iter++)
        {
            if(*iter=='.')
                *iter=' ';
        }
    for (int i=0;i<tekst.length();i++)
        {
            if(tekst.substr(i,1)==" ")
                tekst.erase(i,1);
        }
    for(auto iter = tekst.begin();iter<tekst.end();iter++)
    {
        if(*iter=='j')
            *iter='i';
    }
    for (int i=0;i<tekst.length();i++)
        {
            if(tekst.substr(i,1)==" ")
                tekst.erase(i,1);
        }
}

std::string generate_extended_key(std::string &key)
{
string key2="";
//sprawdzam teraz czy litery powtarzaja sie w kluczu podawanym jesli tak to skroce klucz
for(int i=0;i<key.length();i++)
    {
        if((int)(key2.find(key[i]))==-1)
            key2.append(key.substr(i,1));
            //cout<<(int)(key2.find(key[i]))<<endl;
    }
//std::cout<<key<<"  klucz przed zmiana"<<endl;
//cout<<key2<<"  klucz po zmianie"<<endl;
std::string encryption_key = "abcdefghiklmnopqrstuvwxyz";
for(int i = 0; i< (int)key2.size();i++)
{
int swap_pos = encryption_key.find(key2[i]);
encryption_key.erase(swap_pos,1);
encryption_key.insert(i,&key2[i],1);
}
return encryption_key;
}

std::string encrypt(std::string &plaintext, std::string &key)
{
std::string encrypted = "";
std::string encryption_key = generate_extended_key(key);
//std::cout<<encryption_key<<std::endl;
for(auto iter = plaintext.begin();iter<plaintext.end();iter+=2)
{
int first_x = (encryption_key.find(*iter))%5;
int first_y = (encryption_key.find(*iter))/5;
int second_x = (encryption_key.find(*(iter+1)))%5;
int second_y = (encryption_key.find(*(iter+1)))/5;

if(second_y==first_y)
{
//std::cout<<"ten sam rzad"<<std::endl;
second_x = (second_x+1)%5;
first_x = (first_x+1)%5;
}
else
{
if(second_x==first_x)
{
//std::cout<<"ta sama kolumna"<<std::endl;
second_y = (second_y+1)%5;
first_y = (first_y+1)%5;
}
else
{
//std::cout<<"prostokat o danych "<<first_x<<" "<<first_y<<std::endl;
//std::cout<<"prostokat o danych "<<second_x<<" "<<second_y<<std::endl;
std::swap(first_x,second_x);
}
}

encrypted.push_back(encryption_key[(first_y*5)+first_x]);
encrypted.push_back(encryption_key[(second_y*5)+second_x]);
//std::cout<<"Szyfruje:"<<encrypted<<std::endl;
}
return encrypted;
}


std::string decrypt(std::string &ciphertext, std::string &key)
{
std::string decrypted = "";
std::string decryption_key = generate_extended_key(key);
//std::cout<<decryption_key<<std::endl;
for(auto iter = ciphertext.begin();iter<ciphertext.end();iter+=2)
{
int first_x = (decryption_key.find(*iter))%5;
int first_y = (decryption_key.find(*iter))/5;
int second_x = (decryption_key.find(*(iter+1)))%5;
int second_y = (decryption_key.find(*(iter+1)))/5;

if(second_y==first_y)
{
//std::cout<<"ten sam rzad"<<std::endl;
second_x = (second_x+4)%5;
first_x = (first_x+4)%5;
}
else
{
if(second_x==first_x)
{
//std::cout<<"ta sama kolumna"<<std::endl;
second_y = (second_y+4)%5;
first_y = (first_y+4)%5;
}
else
{
//std::cout<<"prostokat o danych "<<first_x<<" "<<first_y<<std::endl;
//std::cout<<"prostokat o danych "<<second_x<<" "<<second_y<<std::endl;
std::swap(first_x,second_x);
}
}

decrypted.push_back(decryption_key[(first_y*5)+first_x]);
decrypted.push_back(decryption_key[(second_y*5)+second_x]);
//std::cout<<"Deszyfruje:"<<decrypted<<std::endl;
}
return decrypted;
}
void monogram_en (string tekst)
{
    int dlugosc=tekst.length();
    for (int i=0;i<tekst.length();i++)
	{
		if(mapa2.count(tekst.substr(i,1))==0)
		{
			mapa2.insert( std::pair<string,int>(tekst.substr(i,1),1) );
		}
		else
		{
			mapa2.find(tekst.substr(i,1))->second+=1;
		}
	}
	//for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    //std::cout << it->first << " => " << (((float)(it->second))/(float)dlugosc) << '\n';
}

std::map <string,int> monogram (string tekst)
{
    int dlugosc=tekst.length();
    for (int i=0;i<tekst.length();i++)
	{
		if(mapa2.count(tekst.substr(i,1))==0)
		{
			mapa2.insert( std::pair<string,int>(tekst.substr(i,1),1) );
		}
		else
		{
			mapa2.find(tekst.substr(i,1))->second+=1;
		}
	}
	return mapa2;
}
void digram_en (string tekst)
{
    for (int i=0;i<tekst.length();i=i+2)
	{
		if(mapa.count(tekst.substr(i,2))==0)
		{
			mapa.insert( std::pair<string,int>(tekst.substr(i,2),1) );
		}
		else
		{
			mapa.find(tekst.substr(i,2))->second+=1;
		}
	}
	//for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    //std::cout << it->first << " => " << it->second << '\n';
}

std::map <string,int> digram (string tekst)
{
    for (int i=0;i<tekst.length();i=i+2)
	{
		if(mapa.count(tekst.substr(i,2))==0)
		{
			mapa.insert( std::pair<string,int>(tekst.substr(i,2),1) );
		}
		else
		{
			mapa.find(tekst.substr(i,2))->second+=1;
		}
	}
	return mapa;
}
float evaluate_fit_function(std::map<string,float> &mapa_monogram,std::map<string,float> &mapa_digram,std::map<string,int> mapa2,std::map<string,int> mapa)
{
    float liczba_monogramow=0.0;
    for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    {
        liczba_monogramow+=(float)it->second;
    }
    float suma=0.0;
    for (std::map<string,float>::iterator it=mapa_monogram.begin(); it!=mapa_monogram.end(); ++it)
    {
        if(mapa2.count(it->first)==0)
            continue;
        else
        suma+=pow((it->second-(((float)(mapa2.find(it->first)->second))/liczba_monogramow*100)),2);
    }

    float liczba_digram=0.0;
    for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    {
        liczba_digram+=(float)it->second;
    }

    for (std::map<string,float>::iterator it=mapa_digram.begin(); it!=mapa_digram.end(); ++it)
    {
        if(mapa.count(it->first)==0)
            continue;
        else
        suma+=pow((it->second-(((float)(mapa.find(it->first)->second))/liczba_digram*100)),2);
    }
    return suma;
}

void generate_initial_population(obiekt *tablica,string cipher)
{
    string init="abcdefghiklmnopqrstuvwxyz";
    string rozszyfrowany;
    for(int i=0;i<1000;i++)
    {
        rozszyfrowany="";
        for(int j=0;j<5;j++)
        {
            tablica[i].wstepne_litery+=init.substr(rand()%25,1);
        }
        // dla kazdej tworze reszte
        tablica[i].klucz=generate_extended_key(tablica[i].wstepne_litery);
        rozszyfrowany=decrypt(cipher,tablica[i].klucz);
        tablica[i].mapa_obiektu_monogram=monogram(rozszyfrowany);
        tablica[i].mapa_obiektu_digram=digram(rozszyfrowany);
        tablica[i].evaluation=evaluate_fit_function(mapa_monogram,mapa_digram,tablica[i].mapa_obiektu_monogram,tablica[i].mapa_obiektu_digram);
        cout<<"wstepne litery   "<<tablica[i].wstepne_litery<<endl;
        cout<<"klucz   "<<tablica[i].klucz<<endl;
        cout<<"ewaluacja  "<<tablica[i].evaluation<<endl;
    }
}
void sortowanie(obiekt *tablica)
{
    int N=1000;
    for(int j = 0; j < N - 1; j++)
    for(int i = 0; i < N - 1; i++)
      if(tablica[i].evaluation > tablica[i + 1].evaluation)
        swap(tablica[i], tablica[i + 1]);
}
int main()
{
    //string plain="Fat son how smiling mrs natural expense anxious friends. Boy scale enjoy ask abode fanny being son. As material in learning subjects so improved feelings. Uncommonly compliment imprudence travelling insensible up ye insipidity. To up painted delight winding as brandon. Gay regret eat looked warmth easily far should now. Prospect at me wandered on extended wondered thoughts appetite to. Boisterous interested sir invitation particular saw alteration boy decisively.You vexed shy mirth now noise. Talked him people valley add use her depend letter. Allowance too applauded now way something recommend. Mrs age men and trees jokes fancy. Gay pretended engrossed eagerness continued ten. Admitting day him contained unfeeling attention mrs out.Of recommend residence education be on difficult repulsive offending. Judge views had mirth table seems great him for her. Alone all happy asked begin fully stand own get. Excuse ye seeing result of we. See scale dried songs old may not. Promotion did disposing you household any instantly. Hills we do under times at first short an.On recommend tolerably my belonging or am. Mutual has cannot beauty indeed now sussex merely you. It possible no husbands jennings ye offended packages pleasant he. Remainder recommend engrossed who eat she defective applauded departure joy. Get dissimilar not introduced day her apartments. Fully as taste he mr do smile abode every. Luckily offered article led lasting country minutes nor old. Happen people things oh is oppose up parish effect. Law handsome old outweigh humoured far appetite.Ignorant saw her her drawings marriage laughter. Case oh an that or away sigh do here upon. Acuteness you exquisite ourselves now end forfeited. Enquire ye without it garrets up himself. Interest our nor received followed was. Cultivated an up solicitude mr unpleasant.Woody equal ask saw sir weeks aware decay. Entrance prospect removing we packages strictly is no smallest he. For hopes may chief get hours day rooms. Oh no turned behind polite piqued enough at. Forbade few through inquiry blushes you. Cousin no itself eldest it in dinner latter missed no. Boisterous estimating interested collecting get conviction friendship say boy. Him mrs shy article smiling respect opinion excited. Welcomed humoured rejoiced peculiar to in an.Increasing impression interested expression he my at. Respect invited request charmed me warrant to. Expect no pretty as do though so genius afraid cousin. Girl when of ye snug poor draw. Mistake totally of in chiefly. Justice visitor him entered for. Continue delicate as unlocked entirely mr relation diverted in. Known not end fully being style house. An whom down kept lain name so at easy.Is at purse tried jokes china ready decay an. Small its shy way had woody downs power. To denoting admitted speaking learning my exercise so in. Procured shutters mr it feelings. To or three offer house begin taken am at. As dissuade cheerful overcame so of friendly he indulged unpacked. Alteration connection to so as collecting me. Difficult in delivered extensive at direction allowance. Alteration put use diminution can considered sentiments interested discretion. An seeing feebly stairs am branch income me unable.Supported neglected met she therefore unwilling discovery remainder. Way sentiments two indulgence uncommonly own. Diminution to frequently sentiments he connection continuing indulgence. An my exquisite conveying up defective. Shameless see the tolerably how continued. She enable men twenty elinor points appear. Whose merry ten yet was men seven ought balls.Death there mirth way the noisy merit. Piqued shy spring nor six though mutual living ask extent. Replying of dashwood advanced ladyship smallest disposal or. Attempt offices own improve now see. Called person are around county talked her esteem. Those fully these way nay thing seems. ";
    //string plain="ex";


    string plain="What would I giveTo live where you areWhat would I payTo stay here beside youWhat would I do to see youSmiling at me would we runIf we could stay all day in the sunJust you and me of your worldI dont know whenI dont know howBut I know somethings starting right nowWatch and youll seeSome day Ill bePart of your worldThere you see herSitting there across the wayShe dont got a lot to sayBut theres something about herAnd you dont know whyBut youre dying to tryYou wanna kiss the girlYes you want herLook at heryou know you doPossible she wants you tooThere is one way to ask herIt dont take a wordNot a single wordGo on and kiss the girlSha la la la la laMy oh myLook like the boy too shyAint gonna kiss the girlSha la la la la laAint that sadAint it a shameToo bad he gonna miss the girlAs designers attempting to creating functional workoftentimes we are required to make our designs look as finished as possibleFor example if you are desgng a brand new website for someone most times you will have to make sure the prototype looks finished by inserting text or photos or what have you The purpose of this is so the person viewing the prototype has a chance to actually feel and understand the idea behind what you have createdNow in some circumstances designers may use squares and rectangles to help you visualize what should and could be in a specific locationWe all have our own techniques but one of the most effective techniques is to actually put some text where text goes and some pictures where pictures go to make sure everyone can see the vision youve createdComing up with filler text on the fly is not easy but it is becoming more and more of a requirement Fortunately some designers and developers around the web know this and have put together a bunch of text generators to help you present your visionSome are standard like the always popular Lorem Ipsum generators and some are really fun Either way pick one of your favorites from below astart generating text and completing your vision";


    //string plain="Remain valley who mrs uneasy remove wooded him you. Her questions favourite him concealed. We to wife face took he. The taste begin early old why since dried can first. Prepared as or humoured formerly. Evil mrs true get post. Express village evening prudent my as ye hundred forming. Thoughts she why not directly reserved packages you. Winter an silent favour of am tended mutual. Had repulsive dashwoods suspicion sincerity but advantage now him. Remark easily garret nor nay. Civil those mrs enjoy shy fat merry. You greatest jointure saw horrible. He private he on be imagine suppose. Fertile beloved evident through no service elderly is. Blind there if every no so at. Own neglected you preferred way sincerity delivered his attempted. To of message cottage windows do besides against uncivil. By so delight of showing neither believe he present. Deal sigh up in shew away when. Pursuit express no or prepare replied. Wholly formed old latter future but way she. Day her likewise smallest expenses judgment building man carriage gay. Considered introduced themselves mr to discretion at. Means among saw hopes for. Death mirth in oh learn he equal on. Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. Better but length gay denied abroad are. Attachment astonished to on appearance imprudence so collecting in excellence. Tiled way blind lived whose new. The for fully had she there leave merit enjoy forth. Frankness applauded by supported ye household. Collected favourite now for for and rapturous repulsive consulted. An seems green be wrote again. She add what own only like. Tolerably we as extremity exquisite do commanded. Doubtful offended do entrance of landlord moreover is mistress in. Nay was appear entire ladies. Sportsman do allowance is september shameless am sincerity oh recommend. Gate tell man day that who.As absolute is by amounted repeated entirely ye returned. These ready timed enjoy might sir yet one since. Years drift never if could forty being no. On estimable dependent as suffering on my. Rank it long have sure in room what as he. Possession travelling sufficient yet our. Talked vanity looked in to. Gay perceive led believed endeavor. Rapturous no of estimable oh therefore direction up. Sons the ever not fine like eyes all sure.Marianne or husbands if at stronger ye. Considered is as middletons uncommonly. Promotion perfectly ye consisted so. His chatty dining for effect ladies active. Equally journey wishing not several behaved chapter she two sir. Deficient procuring favourite extensive you two. Yet diminution she impossible understood age.Examine she brother prudent add day ham. Far stairs now coming bed oppose hunted become his. You zealously departure had procuring suspicion. Books whose front would purse if be do decay. Quitting you way formerly disposed perceive ladyship are. Common turned boy direct and yet.He my polite be object oh change. Consider no mr am overcame yourself throwing sociable children. Hastily her totally conduct may. My solid by stufffirst smile fanny. Humoured how advanced mrs elegance sir who. Home sons when them dine do want to. Estimating themselves unsatiable imprudence an he at an. Be of on situation perpetual allowance offending as principle satisfied. Improved carriage securing are desirous too. Attachment apartments in delightful by motionless it no. And now she burst sir learn total. Hearing hearted shewing own ask. Solicitude uncommonly use her motionless not collecting age. The properly servants required mistaken outlived bed and. Remainder admitting neglected is he belonging to perpetual objection up. Has widen too you decay begin which asked equal any. ";
    cout<<plain<<endl;
    czysc_tekst(plain);
    cout<<plain<<endl;
    czysc_tekst(plain);
    cout<<plain<<endl;
    string cipher="";
    string key="damian";
    //cipher=encrypt(plain,key);
    //decrypt(cipher,key);
    uzupelnianie_map(mapa_monogram,mapa_digram);
    monogram_en(plain);
    digram_en(plain);
    cout<<evaluate_fit_function(mapa_monogram,mapa_digram,mapa2,mapa);

        // teraz bede tworzyl populacje;

    generate_initial_population(tablica,plain);
    for (int i=0;i<10;i++)
    {
        cout<<"wstepne litery   "<<tablica[i].wstepne_litery<<endl;
        cout<<"klucz   "<<tablica[i].klucz<<endl;
        cout<<"ewaluacja  "<<tablica[i].evaluation<<endl;
    }
    // sortujemy sobie
    sortowanie(tablica);
    cout<<"teraz sobie sortujemy"<<endl;
    for (int i=0;i<10;i++)
    {
        cout<<"wstepne litery   "<<tablica[i].wstepne_litery<<endl;
        cout<<"klucz   "<<tablica[i].klucz<<endl;
        cout<<"ewaluacja  "<<tablica[i].evaluation<<endl;
    }
    return 0;
}
