#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <algorithm>
#include <locale>
#include <bitset>

using namespace std;
std::map <string,int> mapa;
std::map <string,int> mapa2;
std::map <string,int> mapa3;
std::map <string,int> mapa4;

int ile_bajtow(string myString)
{
  for (std::size_t i = 0; i < myString.size(); ++i)
  {
      cout << bitset<8>(myString.c_str()[i]) << endl;
  }
}
int ile_znakow(string k)
{
    return k.size();
}
int ile_zajmuje(string k1)
{
    char k=k1.c_str()[0];
    //cout<<(int)k<<"\n";
    if((int)(k&0x80)==0)
        return 1;
    else if((int)(k&0x70)==0)
        return 1;
    else if((int)(k&0x70)==64)
        return 2;
    else if((int)(k&0x70)==96)
        return 3;
    else if((int)(k&0x70)==112)
        return 4;
    else
        return 0;

}
void czysc_tekst(string &tekst)
{
    int dlugosc;
    std::transform(tekst.begin(), tekst.end(), tekst.begin(), ::tolower);
    for (int i=0;i<tekst.length();i++)
        {
            dlugosc=ile_zajmuje(tekst.substr(i,1));
            if(tekst.substr(i,dlugosc)==" ")
            {
                tekst.erase(i,1);
            }
        }

}
void monogram_en (string tekst)
{
    for (int i=0;i<tekst.length();i++)
	{
		if(mapa.count(tekst.substr(i,1))==0)
		{
			mapa.insert( std::pair<string,int>(tekst.substr(i,1),1) );
		}
		else
		{
			mapa.find(tekst.substr(i,1))->second+=1;
		}
	}
	for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';
}

void digram_en (string tekst)
{
    for (int i=0;i<tekst.length();i=i+2)
	{
		if(mapa2.count(tekst.substr(i,2))==0)
		{
			mapa2.insert( std::pair<string,int>(tekst.substr(i,2),1) );
		}
		else
		{
			mapa2.find(tekst.substr(i,2))->second+=1;
		}
	}
	for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';
}

void monogram(string tekst)
{
    int dlugosc;
    for(int i=0;i<tekst.length();i++)
    {
        dlugosc=ile_zajmuje(tekst.substr(i,1));
        if(mapa3.count(tekst.substr(i,dlugosc))==0)
		{
			mapa3.insert( std::pair<string,int>(tekst.substr(i,dlugosc),1) );
		}
		else
		{
			mapa3.find(tekst.substr(i,dlugosc))->second+=1;
		}
		i=i+dlugosc-1;
    }
	for (std::map<string,int>::iterator it=mapa3.begin(); it!=mapa3.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';

}
void diagram(string tekst)
{
    int dlugosc;
    int dlugosc2;
    int dlugosc3;
    int liczba_znakow;
    for(int i=0;i<tekst.length();i++)
    {
        dlugosc=ile_zajmuje(tekst.substr(i,1));
        dlugosc2=ile_zajmuje((tekst.substr(i+dlugosc,1)));
        dlugosc3=dlugosc+dlugosc2;


        if(mapa4.count(tekst.substr(i,dlugosc3))==0)
		{
			mapa4.insert( std::pair<string,int>(tekst.substr(i,dlugosc3),1) );
		}
		else
		{
			mapa4.find(tekst.substr(i,dlugosc3))->second+=1;
		}
		i=i+dlugosc3-1;
    }
	for (std::map<string,int>::iterator it=mapa4.begin(); it!=mapa4.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';


}

int main()
{

    ifstream tresc;
    tresc.open("tresc.txt",ios_base::in);
    string tekst;
    getline(tresc,tekst);
    //cout<<tekst<<endl;
    int i=0;
    string tmp=tekst;
    while(tresc.good())
    {
        getline(tresc,tekst);
        tmp.append(tekst);
        //cout<<i<<"  "<<tekst<<endl;
        i++;
    }
    cout<<tmp<<"\n"<<endl;
    tresc.close();
    //monogram_en(tekst);
    //cout<<endl;
    //digram_en(tekst);
    //monogram(tekst);
    czysc_tekst(tmp);
    cout<<tmp<<"\n";
    //diagram(tekst);
    monogram_en(tmp);
    int suma_wszystkich=0;
    for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    {
        std::cout << it->first << " => " << it->second << '\n';
        suma_wszystkich=suma_wszystkich+(it->second);
    }
    cout<<suma_wszystkich<<endl;

    for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    {
        std::cout << it->first << " => " << (float)(((float)(it->second))/((float)(suma_wszystkich))) << '\n';
    }
    digram_en(tmp);

    int suma_wszystkich_di=0;
    for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    {
        std::cout << it->first << " => " << it->second << '\n';
        suma_wszystkich_di=suma_wszystkich_di+(it->second);
    }
    cout<<suma_wszystkich_di<<endl;

    for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    {
        std::cout << it->first << " => " << (float)(((float)(it->second))/((float)(suma_wszystkich_di))) << '\n';
    }
    return 0;
}
