#include <iostream>
#include <fstream>
#include <string>


using namespace std;
void wypisz( int & iLiczba )
{
    std::cout << "Wartosc liczby wynosi: " << iLiczba << std::endl;
    iLiczba += 10;
    std::cout << "Wartosc liczby wynosi: " << iLiczba << std::endl;
}

int main()
{
    int iNaszaLiczba = 7;
    std::cout << "Nasza liczba = " << iNaszaLiczba << std::endl;
    wypisz( iNaszaLiczba );
    std::cout << "Nasza liczba = " << iNaszaLiczba << std::endl;
    ofstream plik2;
    plik2.open("nowy.txt",ios_base::out);//,ios_base::out);//|ios_base::binary);
    plik2<<"hehj";
    plik2.close();
    return 0;
}
