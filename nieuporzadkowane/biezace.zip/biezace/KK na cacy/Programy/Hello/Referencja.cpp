#include <iostream>
#include <fstream>
#include <string>


using namespace std;
void wypisz( int & iLiczba )
{
    std::cout << "Wartosc liczby wynosi: " << iLiczba << std::endl;
    iLiczba += 10;
    std::cout << "Wartosc liczby wynosi: " << iLiczba << std::endl;
}

int main()
{
    int iNaszaLiczba = 7;
    std::cout << "Nasza liczba = " << iNaszaLiczba << std::endl;
    wypisz( iNaszaLiczba );
    std::cout << "Nasza liczba = " << iNaszaLiczba << std::endl;
    ifstream plik;
    plik.open("Damian.txt",ios_base::in|ios_base::binary);//|ios_base::binary);
    ofstream plik2;
    plik2.open("nowy.txt",ios_base::out|ios_base::binary);//,ios_base::out);//|ios_base::binary);
    string s;
    plik>>s;
    while (plik.good())
    {

        plik2<<s;
        plik2<<endl;
        plik>>s;
    }
    plik2<<5;
    plik2<<"hehj";
    plik.close();
    plik2.close();
    return 0;
}
