#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello World!";
    cin.get();
    return 0;
}
