/*#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

void swap(char a)
{
    int i=0,tab[31];
    while(a)
    {
        tab[i++]=a%2;
        a/=2;
    }
      for(int j=i-1;j>=0;j--)
        cout<<tab[j];
}
int main()
{
    char znak='a';
    string x = "a";
    cout<<atoi(x.c_str());
    cout<<endl;
    swap(znak);
    return 0;
}
*/
#include <string>
#include <bitset>
#include <iostream>
using namespace std;
int main(){
  string myString = "భ";
  for (std::size_t i = 0; i < myString.size(); ++i)
  {
      cout << bitset<8>(myString.c_str()[i]) << endl;
  }
}
