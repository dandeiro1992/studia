#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <bitset>
#define SZYFROWANIE true
#define DESZYFROWANIE false

using namespace std;
std::map <string,int> mapa;
int NWD(int a, int b)
{
    while(a!=b)
       if(a>b)
           a-=b;
       else
           b-=a;
    return a;
}
int odwrotnosc_skladnika(int skladnik)
{
    return (32-skladnik)%32;
}
int odwrotnosc (int liczba)
{
    if(NWD(liczba,32)!=1)
    {
        cout<<"nie da sie odszyfrowac-ten klucz jest nieodpowiedni\n";
    }
    else
    {
        int wynik=liczba;
        for(int i=1;i<15;i++)
        {
            wynik=(wynik*liczba)%32;
        }
        return wynik;
    }

}
int ile_bajtow(string myString)
{
  for (std::size_t i = 0; i < myString.size(); ++i)
  {
      cout << bitset<8>(myString.c_str()[i]) << endl;
  }
}
void key_find(string tablica[][2],int &a,int &b)
{
    for(a=0;a<32;a++)
    {
        for (b=0;b<32;b++)
        {
            if((mapa.find(tablica[0][0])->second)==(((a*(mapa.find(tablica[0][1])->second))+b)%32))
            {
                break;
            }
        }
        if((mapa.find(tablica[1][0])->second)==(((a*(mapa.find(tablica[1][1])->second))+b)%32))
        {
            break;
        }
    }
    //cout<<"a:"<<a;
    //cout<<"b:"<<b;
}
string affine(string tekst,int czynnik,int skladnik,bool szyfrowanie)
{
    if(szyfrowanie)
    {
        string k=tekst;

        for(int i=0;i<tekst.length();i++)
        {
            int tmp=((czynnik*(mapa.find(tekst.substr(i,1))->second)+skladnik)%32);
            for(std::map<string,int>::iterator it=mapa.begin();it!=mapa.end();++it)
            {
                if(it->second==tmp)
                {
                    k.replace(i,1,it->first);
                    break;
                }
            }
        }
        return k;
    }
    else
    {
        string jawny=tekst;
        int czynnik2=odwrotnosc(czynnik);
        int skladnik2=odwrotnosc_skladnika(skladnik);
        for(int i=0;i<tekst.length();i++)
        {
            int tmp=((((mapa.find(tekst.substr(i,1))->second))+skladnik2)*czynnik2)%32;
            for(std::map<string,int>::iterator it=mapa.begin();it!=mapa.end();++it)
            {
                if(it->second==tmp)
                {
                    jawny.replace(i,1,it->first);
                    break;
                }
            }
        }
        return jawny;
    }

}
int main()
{
    int a,b;
    int i=0;
    ifstream alfabet;
    alfabet.open("alfabet.txt",ios_base::in);
    string s;
    getline(alfabet,s);
    cout<<s;
    while(alfabet.good())
    {
        mapa.insert(std::pair <string,int>(s,i));
        getline(alfabet,s);
        cout<<s;
        i++;
    }
    alfabet.close();

    for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';

    ifstream szyfrogram;
    szyfrogram.open("szyfrogram.txt",ios_base::in);
    string string_szyfr;
    getline(szyfrogram,string_szyfr);
    cout<<string_szyfr<<endl;
    ifstream zamiana;
    zamiana.open("co_na_co.txt",ios_base::in);
    string tablica[2][2];
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {
            string tmp;
            getline(zamiana,tmp);
            tablica[i][j]=tmp;
        }
    }

    key_find(tablica,a,b);
    cout<<a<<"      "<<b<<endl;
    cout<<odwrotnosc(5)<<endl;;
    cout<<affine(string_szyfr,5,7,DESZYFROWANIE);

    return 0;
}
