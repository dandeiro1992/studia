#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <stdio.h>

using namespace std;

int main()
{
    string s;
    cout<<"wy�wietl liczb�"<<endl;
    cin<<s;
    cout<<s<<endl;
    return 0;
}
