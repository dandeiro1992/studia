﻿#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
#include <map>
#include <stdio.h>

using namespace std;
int ile_zajmuje(string k1)
{
    char k=k1.c_str()[0];
    cout<<(int)k<<"\n";
    if((int)(k&0x80)==0)
        return 1;
    else if((int)(k&0x70)==0)
        return 1;
    else if((int)(k&0x70)==64)
        return 2;
    else if((int)(k&0x70)==96)
        return 3;
    else if((int)(k&0x70)==112)
        return 4;
    else
        return 0;

}
int main()
{
    string s;
    cout<<"wyświetl liczbę"<<endl;
    cin>>s;
    cout<<s<<endl;
    cout<<s.length()<<endl;
    char k=s[0];
    cout<<(int)k<<endl;
    string myString ="aćś";
    string tmp=myString.substr(0,2);
    cout<<tmp<<endl;
  for (std::size_t i = 0; i < myString.size(); ++i)
  {
      cout << bitset<8>(myString.c_str()[i]) << endl;
  }
    cout<<"ok"<<endl;
    string a="ą";
    cout<<(int)a[0]<<endl;
    cout<<ile_zajmuje(myString);
    return 0;
}
