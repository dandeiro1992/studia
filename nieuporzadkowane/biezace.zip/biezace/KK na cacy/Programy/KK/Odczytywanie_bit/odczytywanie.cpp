#include <iostream>
#include <fstream>
#include <string>
#include <map>
#define SZYFROWANIE true
#define DESZYFROWANIE false

using namespace std;

std::map <string,int> mapa;

int main()
{
    int i=0;
    ifstream alfabet;
    alfabet.open("alfabet.txt",ios_base::in);//|ios_base::binary);
    string s;
    getline(alfabet,s);
    cout<<s<<endl;
    while(alfabet.good())
    {
        mapa.insert(std::pair <string,int>(s,i));
        getline(alfabet,s);
        //cout<<s;
        i++;
    }
    alfabet.close();
    for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';
    //cout<<(int)'ą';
    //cout<<(mapa.find("ą")->first);
    return 0;
}
