#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;
string affine(string tekst,int czynnik,int skladnik)
{
    string k;
    for(int i=0;i<tekst.length();i++)
    {
        k[i]=(czynnik*tekst[i]+skladnik);
        return k;
    }

}
int main()
{
    int i=0;
    std::map <char,int> mapa;
    ifstream alfabet;
    alfabet.open("alfabet.txt",ios_base::in);
    char s;
    alfabet>>s;
    while(alfabet.good())
    {
        mapa.insert(std::pair <char,int>(s,i));
        alfabet>>s;
        i++;
    }

    for (std::map<char,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';

    affine("Alamakota",1,0);


    return 0;
}
