#include "Matrix.h"
#include "HillCipher.h"
#include "Vector.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <bitset>
#include <math.h>
#include <algorithm>
#define SZYFROWANIE true
#define DESZYFROWANIE false

using namespace std;
std::map <string,int> mapa;
std::map <string,int> mapa2;
double d = 0;

double det(int n, double **mat)//[3][3])
{
    int c, subi, i, j, subj;
    //double submat[3][3];
        double **submat = new double *[n];
        for ( int i = 0; i < n; ++i )
        {
        submat[i] = new double [n];
        }
    if (n == 2)
    {
        return( (mat[0][0] * mat[1][1]) - (mat[1][0] * mat[0][1]));
    }
    else
    {
        for(c = 0; c < n; c++)
        {
            subi = 0;
            for(i = 1; i < n; i++)
            {
                subj = 0;
                for(j = 0; j < n; j++)
                {
                    if (j == c)
                    {
                        continue;
                    }
                    submat[subi][subj] = mat[i][j];
                    subj++;
                }
                subi++;
            }
        d = d + (pow(-1 ,c) * mat[0][c] * det(n - 1 ,submat));
        }
    }
    return d;
}

void czysc_tekst(string &tekst)
{
    int dlugosc;
    std::transform(tekst.begin(), tekst.end(), tekst.begin(), ::tolower);
    for (int i=0;i<tekst.length();i++)
        {
            if(tekst.substr(i,1)==" ")
            {
                tekst.erase(i,1);
            }
        }

}

void monogram_en (string tekst)
{
    for (int i=0;i<tekst.length();i++)
	{
		if(mapa2.count(tekst.substr(i,1))==0)
		{
			mapa2.insert( std::pair<string,int>(tekst.substr(i,1),1) );
		}
		else
		{
			mapa2.find(tekst.substr(i,1))->second+=1;
		}
	}
	for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';
}

int main()
{
    double tmp;
    int tmp2,dlugosc_text;
    int i=0;
    ifstream alfabet;
    ifstream klucz;
    ifstream tekst_jawny;
    alfabet.open("alfabet.txt",ios_base::in);
    klucz.open("klucz.txt",ios_base::in);
    tekst_jawny.open("tekst.txt",ios_base::in);
    string s;
    string key;
    string text;
    getline(alfabet,s);
    getline (klucz,key);
    getline (tekst_jawny,text);
    string tmp_text=text;
    while(tekst_jawny.good())
    {
        getline (tekst_jawny,text);
        tmp_text.append(text);
    }
    cout<<tmp_text<<"\n"<<endl;
    cout<<s<<endl;
    cout<<key<<endl;
    cout<<text<<endl;
    czysc_tekst(tmp_text);
    cout<<tmp_text<<endl;
    cout<<"dlugosc naszego tekstu ejsciowego"<<tmp_text.length()<<endl;
    dlugosc_text=tmp_text.length();
    tmp=key.length();
    tmp=sqrt(tmp);
    tmp=pow(tmp,2);
    tmp2=(int)tmp;
    if(tmp2!=key.length())
    {
        cout<<"nie da rady"<<endl;
    }
    else
    {

         while(alfabet.good())
    {
        mapa.insert(std::pair <string,int>(s,i));
        getline(alfabet,s);
        cout<<s;
        i++;
    }
    alfabet.close();

    for (std::map<string,int>::iterator it=mapa.begin(); it!=mapa.end(); ++it)
    std::cout << it->first << " => " << it->second << '\n';




    cout<<"zaczynam przypisywac"<<endl;
    Wector wektor(dlugosc_text);
    wektor.przypisanie(tmp_text,mapa);
    wektor.wyswietl();
    int rozmiar=(int)(sqrt(tmp));
    cout<<rozmiar<<"   rozmiar"<<endl;
    Matrix macierz(rozmiar);
    macierz.przypisanie(key,mapa);
    cout<<"wypisuje macierz"<<endl;
    macierz.wyswietl();
    Wector wynik(macierz.get_rozmiar(macierz));

    ///////////////////////////////////
    cout<<"mnoze macierze"<<endl;
    HillCipher szyfr;
    szyfr.Encrypt2(macierz,wektor,wynik,mapa,"szyfr.txt");
    //szyfr.Decrypt2(macierz,wektor,wynik,mapa,"szyfr.txt");

    //biore sie za sprawdzanie hipotezy ze zaszyfrowany szyfr przypomina ciag losowy o rozkladnie jednostajnym
    cout<<"sprawdzam hipoteze odnoscie rozkladu jednostajnego"<<endl;
    cout<<"na poczatek czestosc wystepowania znakow w szyfrogramie"<<endl;
    ifstream szyfrogram;
    szyfrogram.open("szyfr.txt",ios_base::in);
    string szyfr_rozklad;
    getline(szyfrogram,szyfr_rozklad);
    cout<<szyfr_rozklad<<endl;

    monogram_en(szyfr_rozklad);
    cout<<"liczymy wartosc statystyki testowej  "<<endl;
    double statystyka=0;
    int proba=szyfr_rozklad.length();
    cout<<"proba"<<(proba)<<endl;
    for (std::map<string,int>::iterator it=mapa2.begin(); it!=mapa2.end(); ++it)
    {
        cout<<it->second<<endl;
        statystyka+=((double)(it->second)-((double)proba/26))*((double)(it->second)-((double)proba/26));
    }
    statystyka=statystyka/((double)proba/26);
    cout<<"statystyka wynosi   "<<statystyka<<endl;
    if(statystyka>14,61)
        cout<<"niestety rozklad nie jest rownomiermy z poziomem istotnosci testu 0,05 i 25 stopniami sswobody"<<endl;
    else
        cout<<"jest bardzo dobrze"<<endl;
    szyfrogram.close();
    alfabet.close();
    klucz.close();
    tekst_jawny.close();
    }
    return 0;

}
