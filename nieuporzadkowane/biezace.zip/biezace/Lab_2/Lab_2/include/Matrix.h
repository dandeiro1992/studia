#ifndef MATRIX_H
#define MATRIX_H
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <bitset>
#include <math.h>
#define SZYFROWANIE true
#define DESZYFROWANIE false

class Matrix
{
    public:
        //Matrix();
        Matrix(int t);
        virtual ~Matrix();
        bool czy_odwracalna(Matrix m);
        void przypisanie(std::string key,std::map <std::string,int> mapa);
        //void odwrotna();
        void macierz_odwrotna();
        void transponowana();
        int dopelnienie(int n, int **mat, int wiersz, int kolumna);
        static int NWD(int a, int b);
        static int odwrotnosc (int liczba);
        int det(int n, int **mat);
        int get_rozmiar(Matrix m);
        void set_rozmiar(int t);
        void wyswietl();
        int **tablica;
        int rozmiar;
    protected:

    private:
        //int rozmiar;
        //int **tablica;
};

#endif // MATRIX_H
