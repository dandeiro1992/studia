#ifndef HILLCIPHER_H
#define HILLCIPHER_H
#include "Matrix.h"
#include "Vector.h"
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <bitset>
#include <math.h>
#define SZYFROWANIE true
#define DESZYFROWANIE false
//class Matrix;
//class Wector;
using namespace std;

class HillCipher
{
    public:
        HillCipher();
        virtual ~HillCipher();
        void Encrypt(Matrix m, Wector w, Wector &wynik,std::map <std::string,int> mapa,string plik);
        void Encrypt2(Matrix m, Wector w, Wector &wynik,std::map <std::string,int> mapa,string plik);
        void Decrypt(Matrix m, Wector w, Wector &wynik,std::map <std::string,int> mapa,string plik);
        void Decrypt2(Matrix m, Wector w, Wector &wynik,std::map <std::string,int> mapa,string plik);
    protected:

    private:

};

#endif // HILLCIPHER_H
