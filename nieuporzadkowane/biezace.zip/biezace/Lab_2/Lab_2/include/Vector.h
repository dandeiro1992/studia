#ifndef VECTOR_H
#define VECTOR_H
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <bitset>
#include <math.h>
#define SZYFROWANIE true
#define DESZYFROWANIE false

using namespace std;

class Wector
{
public:
        Wector(int t);
        virtual ~Wector();
        int get_rozmiar(Wector m);
        void set_rozmiar(int t);
        void wyswietl();
        void przypisanie(std::string tekst_jawny,std::map <std::string,int> mapa);
        int *tablica;
    protected:

    private:
    int rozmiar;

};

#endif // VECTOR_H
