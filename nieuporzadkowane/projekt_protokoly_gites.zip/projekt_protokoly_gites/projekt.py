import sys
from socket import socket, AF_INET, SOCK_DGRAM, SOCK_STREAM
from threading import *
from struct import *
import struct

numer_tajemnicy=2

kluczeA=[1,1]
tablica_losowych=[1708,711,1969,3112,4014,2308,2212,222]
ip_bogiel='192.168.0.107'
ip_krata='192.168.0.104'
port=5000

nr_tajemnicy=2



def send_msg(sock, msg):
    # Prefix each message with a 4-byte length (network byte order)
    msg = struct.pack('>I', len(msg)) + msg
    sock.sendall(msg)

def recv_msg(sock):
    # Read message length and unpack it into an integer
    raw_msglen = recvall(sock, 4)
    if not raw_msglen:
        return None
    msglen = struct.unpack('>I', raw_msglen)[0]
    # Read the message data
    return recvall(sock, msglen)

def recvall(sock, n):
    # Helper function to recv n bytes or return None if EOF is hit
    data = b''
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data += packet
    return data







class Zadanie(Thread):

    def __init__(self, clientsocket, addr):
        Thread.__init__(self)
        self.clientsocket=clientsocket
        self.addr=addr

    def run(self):
        self.clientsocket.sendto(data.encode(),(self.addr))
        




class myThread(Thread):

    def __init__(self, clientsocket, addr):
        Thread.__init__(self)
        self.clientsocket=clientsocket
        self.addr=addr

    def run(self):
        while True:
            data=self.clientsocket.recv(1024)
            if not data:
                break
            print("wiadomosc dostalem od"+str(self.addr[0]))
            print ("from connected user: " + data.decode())
            data=(data.decode()).upper()
            print ("sending: " + str(data))
            tablica_slow.append(data)
            print (tablica_slow[0])
            self.clientsocket.sendto(data.encode(),(self.addr))
        clientsocket.close()







def Main():
    host='192.168.0.104'
    
    size=1024
    print ("Test client sending packets to IP {0}, via port {1}\n".format(host, port))


    krata=socket(AF_INET, SOCK_STREAM) # uzytkownik A
    krata.connect((ip_krata,port))
    
    bogiel=socket(AF_INET, SOCK_STREAM) # uzytkownik B
    bogiel.connect((ip_bogiel,port))
    
    liczby_B=[]
    
    
        
    data = recv_msg(krata)
    print ('Received from krata: ' + data.decode())
    n=int(data.decode())

    data = recv_msg(krata)
    print ('Received from krata: ' + data.decode())
    klucz_jawny=int(data.decode())
        

    for i in tablica_losowych:            
        m=str(i)
        send_msg(bogiel,m.encode()) # wysylam swoje liczby losowe


    for i in range (0,8):
        data=recv_msg(bogiel) # odbieram liczby losowe uzytkownika B
        liczby_B.append(int(data.decode()))


    cipher=pow(liczby_B[nr_tajemnicy-1], klucz_jawny, n)^liczby_B[nr_tajemnicy-1]          
    print (cipher)
        
        
    send_msg(bogiel,str(cipher).encode())
    data=recv_msg(bogiel)

    bogiel_cipher=int(data.decode())

    print('bogiel cipher')
    print(bogiel_cipher)

    liczby_B_xor=[]
    for i in tablica_losowych:
        liczby_B_xor.append(i^bogiel_cipher)

    print('Liczby xor')
    print(liczby_B_xor)

    for i in liczby_B_xor:            
        m=str(i)
        send_msg(krata,m.encode()) # wysylam indeksy zgodnosci bitowej

    decipher=[]
    for i in range (0,8):
        data=recv_msg(krata) # odbieram zdeszyfrowane wartosci od uzytkownika A
        decipher.append(int(data.decode()))

    print('decipher')
    print(decipher)
    
    tajemnica = decipher[nr_tajemnicy-1] ^ liczby_B[nr_tajemnicy-1]
    print (tajemnica)

        
    bogiel.close()
    krata.close()
    








if __name__=='__main__':
    Main()
