from threading import *
from struct import *
import struct
import sys
from socket import socket, gethostbyname, AF_INET, SOCK_DGRAM, SOCK_STREAM
tablica_kluczy=[7387,5145,777,2747,1421,2261]
tablica_tajemnic=[1990,471,3860,1487,2235,3751,2546,4043]
tablica_bogiel=[]
tablica_iwasiuk=[]
ip_bogiel='192.168.0.107'
ip_iwasiuk='192.168.0.105'
ip_krata='192.168.0.104'
port=5000

def send_msg(sock, msg):
    # Prefix each message with a 4-byte length (network byte order)
    msg = struct.pack('>I', len(msg)) + msg
    sock.sendall(msg)

def recv_msg(sock):
    # Read message length and unpack it into an integer
    raw_msglen = recvall(sock, 4)
    if not raw_msglen:
        return None
    msglen = struct.unpack('>I', raw_msglen)[0]
    # Read the message data
    return recvall(sock, msglen)

def recvall(sock, n):
    # Helper function to recv n bytes or return None if EOF is hit
    data = b''
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data += packet
    return data


def Main():
    hostName = gethostbyname('0.0.0.0')
    krata=socket(AF_INET, SOCK_STREAM)
    krata.bind((hostName,port))
    krata.listen()

    bogiel, addr_bogiel=krata.accept()
    iwasiuk, addr_iwasiuk=krata.accept()

    print (addr_bogiel[0])
    print (addr_iwasiuk[0])

    
    data=tablica_kluczy[0]
    send_msg(bogiel,(str(data)).encode())
    data=tablica_kluczy[1]
    send_msg(bogiel,(str(data)).encode())
    
    data=tablica_kluczy[3]
    send_msg(iwasiuk,(str(data)).encode())
    data=tablica_kluczy[4]
    send_msg(iwasiuk,(str(data)).encode())

    for i in range (0,8):
        data=recv_msg(bogiel)
        tablica_bogiel.append(int(data))

    print (tablica_bogiel)

    for i in range (0,8):
        data=recv_msg(iwasiuk)
        tablica_iwasiuk.append(int(data))

    print (tablica_iwasiuk)

    for i in range(0,8):
        tablica_bogiel[i]=(pow(tablica_bogiel[i],tablica_kluczy[5],tablica_kluczy[3]))^tablica_tajemnic[i]

    for i in range(0,8):
        tablica_iwasiuk[i]=(pow(tablica_iwasiuk[i],tablica_kluczy[2],tablica_kluczy[0]))^tablica_tajemnic[i]

    print (tablica_bogiel)
    print (tablica_iwasiuk)
    for i in range (0,8):
        data=tablica_bogiel[i]
        send_msg(iwasiuk,str(data).encode())

    for i in range (0,8):
        data=tablica_iwasiuk[i]
        send_msg(bogiel,str(data).encode())
        
    krata.close()
    
    
if __name__=='__main__':
    Main()
