import sys
from socket import *
from threading import *
import struct
import time

def send_msg(sock, msg):
    # Prefix each message with a 4-byte length (network byte order)
    msg = struct.pack('>I', len(msg)) + msg
    sock.sendall(msg)

def recv_msg(sock):
    # Read message length and unpack it into an integer
    raw_msglen = recvall(sock, 4)
    if not raw_msglen:
        return None
    msglen = struct.unpack('>I', raw_msglen)[0]
    # Read the message data
    return recvall(sock, msglen)

def recvall(sock, n):
    # Helper function to recv n bytes or return None if EOF is hit
    data = b''
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data += packet
    return data

def Main():
    ip_krata='192.168.0.104'
    port=5000
    tablica_losowa=[743, 1988, 4001, 2942, 3421, 2210, 2306, 222]
    liczby_C=[]
    liczby_Cxor=[]
    liczby_tajne=[]
    nr_tajemnicy=7
    serverHost=gethostbyname('0.0.0.0')
    

    krata=socket(AF_INET, SOCK_STREAM)
    krata.connect((ip_krata, port))
    
    temp=socket(AF_INET, SOCK_STREAM) 
    temp.bind((serverHost ,port))
    temp.listen()
    iwas, addr_iwas=temp.accept()

    print (addr_iwas[0])
    data=recv_msg(krata)
    n=int(data.decode())
    print (n)
    
    data=recv_msg(krata)
    klucz_jawny=int(data.decode())    
    print (klucz_jawny) 


    for i in range (0,8):
        data=recv_msg(iwas)
        liczby_C.append(int(data.decode()))
    print(liczby_C)        
        
        
    for i in tablica_losowa:
            m=str(i)
            send_msg(iwas, m.encode())

    cipher=pow(liczby_C[nr_tajemnicy-1], klucz_jawny, n)^liczby_C[nr_tajemnicy-1]
    data=recv_msg(iwas)
    iwascipher=int(data.decode())
    print('izb')
    print(iwascipher)

    m=str(cipher)
    send_msg(iwas, m.encode())

    for i in tablica_losowa:
        liczby_Cxor.append(i^iwascipher)

    print('liczby Xor')    
    print(liczby_Cxor)
    
    for i in liczby_Cxor:
        m=str(i)
        send_msg(krata, m.encode())

    for i in range(0,8):
        data=recv_msg(krata)
        liczby_tajne.append(int(data.decode()))

    print(liczby_tajne)
    print(liczby_C[6]^liczby_tajne[6])
if __name__=='__main__':
    Main()
